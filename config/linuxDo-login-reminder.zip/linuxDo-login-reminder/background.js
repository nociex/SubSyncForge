// 初始化扩展
chrome.runtime.onInstalled.addListener(() => {
    console.log("Linux.do 登录提醒器已安装");

    // 初始化存储
    chrome.storage.local.get(["visitLog", "emailConfig"], (result) => {
        if (!result.visitLog) {
            chrome.storage.local.set({ visitLog: {} });
        }

        if (!result.emailConfig) {
            chrome.storage.local.set({
                emailConfig: {
                    enabled: false,
                    email: "",
                    emailjsPublicKey: "",
                    serviceId: "",
                    templateId: "",
                },
            });
        }
    });

    // 设置每日检查闹钟（在每天18点触发）
    chrome.alarms.create("dailyCheck", {
        when: getNext18OClock(),
        periodInMinutes: 24 * 60, // 24小时
    });
});

// 处理来自 content script 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "recordVisit") {
        recordTodayVisit();
    } else if (message.action === "saveEmailConfig") {
        saveEmailConfig(message.config);
        sendResponse({ success: true });
    } else if (message.action === "getEmailConfig") {
        chrome.storage.local.get("emailConfig", (result) => {
            sendResponse(result.emailConfig || {});
        });
        return true; // 表示将异步发送回复
    } else if (message.action === "getVisitLog") {
        chrome.storage.local.get("visitLog", (result) => {
            sendResponse(result.visitLog || {});
        });
        return true; // 表示将异步发送回复
    } else if (message.action === "testEmail") {
        sendTestEmail(message.config)
            .then(() => sendResponse({ success: true }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true; // 表示将异步发送回复
    }
});

// 闹钟处理器
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "dailyCheck") {
        checkTodayVisit();
    }
});

// 获取格式化的当前日期（考虑本地时区）
function getFormattedDate(date) {
    return date
        .toLocaleDateString("zh-CN", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
        })
        .replace(/\//g, "-");
}

// 记录今天的访问
function recordTodayVisit() {
    // 修改：使用本地时区格式化日期
    const today = getFormattedDate(new Date());

    chrome.storage.local.get("visitLog", (result) => {
        const visitLog = result.visitLog || {};
        visitLog[today] = true;

        chrome.storage.local.set({ visitLog: visitLog }, () => {
            console.log(`记录今天(${today})的访问`);
        });
    });
}

// 检查今天是否访问了网站
function checkTodayVisit() {
    // 获取今天的日期
    const today = getFormattedDate(new Date());

    chrome.storage.local.get(["visitLog", "emailConfig"], (result) => {
        const visitLog = result.visitLog || {};
        const emailConfig = result.emailConfig || {};

        if (!visitLog[today] && emailConfig.enabled) {
            // 今天还没有访问，发送提醒邮件
            sendReminderEmail(emailConfig, today);

            // 显示通知
            chrome.notifications.create({
                type: "basic",
                iconUrl: "images/icon128.png",
                title: "登录提醒",
                message: `您今天(${today})还没有访问 linux.do，已发送提醒邮件。`,
            });
        }
    });
}

// 检查昨天是否访问了网站 (保留这个函数以防将来需要)
function checkYesterdayVisit() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    // 修改：使用本地时区格式化日期
    const yesterdayStr = getFormattedDate(yesterday);

    chrome.storage.local.get(["visitLog", "emailConfig"], (result) => {
        const visitLog = result.visitLog || {};
        const emailConfig = result.emailConfig || {};

        if (!visitLog[yesterdayStr] && emailConfig.enabled) {
            // 昨天没有访问，发送提醒邮件
            sendReminderEmail(emailConfig, yesterdayStr);

            // 显示通知
            chrome.notifications.create({
                type: "basic",
                iconUrl: "images/icon128.png",
                title: "登录提醒",
                message: `您昨天(${yesterdayStr})没有访问 linux.do，已发送提醒邮件。`,
            });
        }
    });
}

// 发送提醒邮件
function sendReminderEmail(config, date) {
    if (!config.enabled || !config.email) {
        console.error("邮件配置未完成或未启用");
        return;
    }

    // 使用 EmailJS REST API 来发送邮件
    const emailData = {
        service_id: config.serviceId || "default_service",
        template_id: config.templateId || "template_reminder",
        user_id: config.emailjsPublicKey,
        template_params: {
            to_email: config.email,
            date: date,
            // 注意：如果您的模板中定义了其他参数，也需要在这里添加
        },
    };

    console.log(`尝试使用REST API发送提醒邮件到 ${config.email}, 日期: ${date}`);

    // 发送请求
    fetch("https://api.emailjs.com/api/v1.0/email/send", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(emailData),
        })
        .then((response) => {
            if (response.ok) {
                console.log(`已成功发送提醒邮件到 ${config.email}`);
                // 可以在这里添加成功通知
            } else {
                return response.text().then((text) => {
                    console.error(`发送邮件失败: HTTP ${response.status} - ${text}`);
                    throw new Error(`发送邮件失败: ${text}`);
                });
            }
        })
        .catch((error) => {
            console.error("邮件发送错误:", error.message);
            // 可以考虑在这里添加失败通知或重试逻辑
        });
}

// 发送测试邮件
function sendTestEmail(config) {
    return new Promise((resolve, reject) => {
        if (!config.email) {
            reject(new Error("请提供有效的邮箱地址"));
            return;
        }

        // 验证 EmailJS Public Key
        if (!config.emailjsPublicKey) {
            reject(new Error("请提供有效的 EmailJS Public Key"));
            return;
        }

        // 获取当前日期作为测试
        const currentDate = getFormattedDate(new Date());

        // 构建测试邮件数据
        const emailData = {
            service_id: config.serviceId,
            template_id: config.templateId,
            user_id: config.emailjsPublicKey,
            template_params: {
                to_email: config.email,
                date: currentDate,
                // 如果您的模板需要其他参数，请在这里添加
            },
        };

        console.log(
            `尝试使用REST API发送测试邮件到 ${config.email}, 使用公钥: ${config.emailjsPublicKey}`
        );

        // 发送请求
        fetch("https://api.emailjs.com/api/v1.0/email/send", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(emailData),
            })
            .then((response) => {
                if (response.ok) {
                    console.log(`测试邮件已成功发送到 ${config.email}`);
                    resolve();
                } else {
                    return response.text().then((text) => {
                        console.error(
                            `发送测试邮件失败: HTTP ${response.status} - ${text}`
                        );
                        throw new Error(`发送测试邮件失败: ${text}`);
                    });
                }
            })
            .catch((error) => {
                console.error("测试邮件发送错误:", error.message);
                reject(error);
            });
    });
}

// 保存邮件配置
function saveEmailConfig(config) {
    chrome.storage.local.set({ emailConfig: config }, () => {
        console.log("已保存邮件配置:", config);
    });
}

// 获取下一个18点的时间戳
function getNext18OClock() {
    const now = new Date();
    const today18 = new Date(now);
    today18.setHours(18, 0, 0, 0);

    // 如果当前时间已经过了今天的18点，则设置为明天18点
    if (now.getTime() > today18.getTime()) {
        today18.setDate(today18.getDate() + 1);
    }

    return today18.getTime();
}

// 获取下一个午夜的时间戳 (保留这个函数以防将来需要)
function getNextMidnight() {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    return tomorrow.getTime();
}