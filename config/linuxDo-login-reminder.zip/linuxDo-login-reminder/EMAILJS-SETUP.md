# EmailJS 配置指南

本文档将指导您如何为 Linux.do 登录提醒器设置 EmailJS 服务。

## 步骤一：注册 EmailJS 账户

1. 访问 [EmailJS 官网](https://www.emailjs.com/) 并注册一个账户
2. 选择免费计划即可（每月可发送 200 封邮件）

## 步骤二：添加电子邮件服务

1. 登录您的 EmailJS 账户
2. 点击左侧菜单中的 **"Email Services"**
3. 点击 **"Add New Service"**
4. 选择您想使用的邮件服务提供商（如 Gmail、Outlook、自定义 SMTP 等）
5. 按照提示完成配置，您需要提供邮箱凭据
6. 完成后，您会获得一个 **Service ID**，记下它（形式如 `service_xxxxxxx`）

## 步骤三：创建邮件模板

1. 在 EmailJS 控制面板中，点击左侧菜单中的 **"Email Templates"**
2. 点击 **"Create New Template"**
3. 为模板设置一个名称，例如 "Linux.do Login Reminder"
4. 在内容编辑器中，设置邮件内容：

**主题 (Subject):**
```
[提醒] 您在 {{date}} 没有访问 linux.do
```

**邮件内容 (Content):**
```html
<!DOCTYPE html>
<html>
<head>
    <title>Linux.do 登录提醒</title>
</head>
<body>
    <h2>Linux.do 登录提醒</h2>
    <p>亲爱的用户，</p>
    <p>您在 {{date}} 没有访问 linux.do 网站。这是一个友好的提醒，请记得登录以保持您的账户活跃。</p>
    <p>此致，<br>Linux.do 登录提醒器</p>
</body>
</html>
```

5. 保存模板后，您会获得一个 **Template ID**，记下它（形式如 `template_xxxxxxx`）

### 重要说明：关于模板参数

在上面的模板中，我们使用了以下模板变量：
- `{{date}}`: 会被替换为日期

扩展会自动传递以下参数到您的 EmailJS 模板：
- `to_email`: 接收邮件的地址（您在扩展中设置的邮箱）
- `date`: 日期（如 "2023-05-23"）

如果您修改了模板或添加了其他变量，需要确保：
1. 变量名称在模板中使用双大括号包围：`{{变量名}}`
2. 在 background.js 中的 `sendReminderEmail` 和 `sendTestEmail` 函数中添加相应的参数

## 步骤四：获取 Public Key

1. 在 EmailJS 控制面板中，点击左侧菜单中的 **"Account"**
2. 点击 **"API Keys"** 标签页或查找 **"Integration"** 部分
3. 您会看到您的 **Public Key**
4. 复制此 Public Key 用于扩展配置

## 步骤五：调整安全设置

1. 在 EmailJS 控制面板中，点击左侧菜单中的 **"Account"**
2. 点击 **"Security"** 标签页
3. 确保 **"Allow EmailJS API for non-browser applications"** 选项已启用（这对于 Chrome 扩展可能很重要）

## 步骤六：在扩展中配置 EmailJS

1. 打开 Linux.do 登录提醒器的扩展设置
2. 输入您的 **接收提醒的邮箱地址**
3. 输入您的 **EmailJS Public Key**
4. 输入您的 **Service ID** (如 service_xxxxxxx)
5. 输入您的 **Template ID** (如 template_xxxxxxx)
6. 启用邮件提醒
7. 点击 **"保存设置"**
8. 使用 **"测试邮件"** 按钮来验证配置是否成功

## 工作原理

1. 扩展会记录每天您访问 linux.do 的情况
2. 每天18:00，扩展会检查您当天是否访问了 linux.do
3. 如果当天没有访问，扩展将通过 EmailJS 发送提醒邮件到您设置的邮箱
4. 您也会收到一个浏览器通知提醒您

## 故障排除

如果您在配置过程中遇到问题：

1. **公钥无效错误**: 
   - 确保您复制了正确的 Public Key
   - 确认您在使用最新的 EmailJS API

2. **邮件发送失败**: 
   - 检查您的邮件服务配置，确保密码和服务设置正确
   - 查看浏览器控制台中的错误消息，可能会提供更具体的错误信息
   - 验证 EmailJS 控制面板中您的 Service 状态是否为 "Connected"

3. **模板错误**: 
   - 确保 Template ID 正确，并且模板参数匹配
   - 检查模板中的变量是否与代码中提供的参数一致

4. **API 访问限制**: 
   - 在 Account > Security 中确保已启用 API 访问
   - 检查是否达到了免费计划的每月限制（200 封邮件）

## EmailJS API 参考

您的扩展使用的是 EmailJS REST API，主要用于从后台脚本发送邮件。如果您想了解更多，可以参考以下资源：

- [EmailJS 文档](https://www.emailjs.com/docs/)
- [REST API 发送邮件](https://www.emailjs.com/docs/rest-api/send/)
- [模板参数使用指南](https://www.emailjs.com/docs/user-guide/dynamic-variables-templates/)

## 附加信息

- 免费账户每月可发送 200 封邮件
- EmailJS 可以与多种邮件服务提供商配合使用
- 您可以创建多个邮件模板用于不同用途
- EmailJS 提供了详细的发送日志，可在控制面板中查看 