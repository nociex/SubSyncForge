// 初始化 popup 页面
document.addEventListener("DOMContentLoaded", function() {
    // 标签页切换
    const tabs = document.querySelectorAll(".tab");
    tabs.forEach((tab) => {
        tab.addEventListener("click", () => {
            const tabId = tab.getAttribute("data-tab");

            // 更新活动标签
            tabs.forEach((t) => t.classList.remove("active"));
            tab.classList.add("active");

            // 更新活动内容
            document.querySelectorAll(".tab-content").forEach((content) => {
                content.classList.remove("active");
            });
            document.getElementById(tabId).classList.add("active");

            // 如果切换到日志标签，加载访问记录
            if (tabId === "logs") {
                loadVisitLog();
            }
        });
    });

    // 添加设置帮助链接
    document.getElementById("setup-help").addEventListener("click", function(e) {
        e.preventDefault();
        chrome.tabs.create({ url: chrome.runtime.getURL("EMAILJS-SETUP.md") });
    });

    // 加载设置
    loadSettings();

    // 保存设置按钮
    document
        .getElementById("save-settings")
        .addEventListener("click", saveSettings);

    // 测试邮件按钮
    document.getElementById("test-email").addEventListener("click", testEmail);
});

// 加载设置
function loadSettings() {
    chrome.runtime.sendMessage({ action: "getEmailConfig" }, (response) => {
        if (response) {
            document.getElementById("enable-email").checked =
                response.enabled || false;
            document.getElementById("email").value = response.email || "";

            // EmailJS 设置 - 更新为 Public Key
            if (response.emailjsPublicKey) {
                document.getElementById("emailjs-public-key").value =
                    response.emailjsPublicKey;
            }

            // Service ID 和 Template ID
            if (response.serviceId) {
                document.getElementById("service-id").value = response.serviceId;
            }

            if (response.templateId) {
                document.getElementById("template-id").value = response.templateId;
            }
        }
    });
}

// 保存设置
function saveSettings() {
    const enabled = document.getElementById("enable-email").checked;
    const email = document.getElementById("email").value.trim();
    const emailjsPublicKey = document
        .getElementById("emailjs-public-key")
        .value.trim();
    const serviceId = document.getElementById("service-id").value.trim();
    const templateId = document.getElementById("template-id").value.trim();

    // 验证邮箱
    if (enabled && !isValidEmail(email)) {
        showStatus("请输入有效的邮箱地址", "error");
        return;
    }

    // 验证 EmailJS Public Key
    if (enabled && !emailjsPublicKey) {
        showStatus("请输入 EmailJS Public Key", "error");
        return;
    }

    // 验证 EmailJS Service ID 和 Template ID
    if (enabled && !serviceId) {
        showStatus("请输入 EmailJS Service ID", "error");
        return;
    }

    if (enabled && !templateId) {
        showStatus("请输入 EmailJS Template ID", "error");
        return;
    }

    const config = {
        enabled: enabled,
        email: email,
        emailjsPublicKey: emailjsPublicKey,
        serviceId: serviceId,
        templateId: templateId,
    };

    chrome.runtime.sendMessage({
            action: "saveEmailConfig",
            config: config,
        },
        (response) => {
            if (response && response.success) {
                showStatus("设置已保存", "success");
            } else {
                showStatus("保存设置失败", "error");
            }
        }
    );
}

// 测试邮件发送
function testEmail() {
    const email = document.getElementById("email").value.trim();
    const emailjsPublicKey = document
        .getElementById("emailjs-public-key")
        .value.trim();
    const serviceId = document.getElementById("service-id").value.trim();
    const templateId = document.getElementById("template-id").value.trim();

    if (!isValidEmail(email)) {
        showStatus("请输入有效的邮箱地址", "error");
        return;
    }

    if (!emailjsPublicKey) {
        showStatus("请输入 EmailJS Public Key", "error");
        return;
    }

    if (!serviceId) {
        showStatus("请输入 EmailJS Service ID", "error");
        return;
    }

    if (!templateId) {
        showStatus("请输入 EmailJS Template ID", "error");
        return;
    }

    showStatus("正在发送测试邮件...", "");

    chrome.runtime.sendMessage({
            action: "testEmail",
            config: {
                email: email,
                emailjsPublicKey: emailjsPublicKey,
                serviceId: serviceId,
                templateId: templateId,
            },
        },
        (response) => {
            if (response && response.success) {
                showStatus("测试邮件发送成功！", "success");
            } else {
                showStatus(
                    `测试邮件发送失败: ${response ? response.error : "未知错误"}`,
                    "error"
                );
            }
        }
    );
}

// 加载访问记录
function loadVisitLog() {
    const logContainer = document.getElementById("visit-log");
    logContainer.innerHTML = '<div class="loading">加载中...</div>';

    chrome.runtime.sendMessage({ action: "getVisitLog" }, (visitLog) => {
        if (!visitLog || Object.keys(visitLog).length === 0) {
            logContainer.innerHTML = '<div class="no-records">暂无访问记录</div>';
            return;
        }

        // 将日期排序（最新的在前面）
        const sortedDates = Object.keys(visitLog).sort(
            (a, b) => new Date(b) - new Date(a)
        );

        let html = "";

        // 修复：获取当前时间时考虑本地时区
        const now = new Date();
        const today = now
            .toLocaleDateString("zh-CN", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
            })
            .replace(/\//g, "-");

        // 昨天的日期
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday
            .toLocaleDateString("zh-CN", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
            })
            .replace(/\//g, "-");

        sortedDates.forEach((date) => {
            let dateLabel = date;

            // 为今天和昨天添加标签
            if (date === today) {
                dateLabel += " (今天)";
            } else if (date === yesterdayStr) {
                dateLabel += " (昨天)";
            }

            html += `<div class="visit-item">
        <span class="visit-date">${dateLabel}</span>: 已访问
      </div>`;
        });

        logContainer.innerHTML = html;
    });
}

// 显示状态消息
function showStatus(message, type) {
    const statusEl = document.getElementById("status");
    statusEl.textContent = message;
    statusEl.className = "status";

    if (type) {
        statusEl.classList.add(type);
    }

    statusEl.style.display = "block";

    // 自动隐藏成功消息
    if (type === "success") {
        setTimeout(() => {
            statusEl.style.display = "none";
        }, 3000);
    }
}

// 验证邮箱
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}