// 当页面加载完成时，向 background.js 发送消息，表示今天已访问 linux.do
console.log("Linux.do 访问记录器已激活");

// 发送消息到后台脚本，记录今天的访问
chrome.runtime.sendMessage({ action: "recordVisit" });